public class HelloWorld {

    public static void main(String[] args) {
        // Prints "Hello, World" to the terminal window.
        System.out.println("Hello, World");
    }

}





//import org.apache.commons.lang3.StringUtils;
//
//import com.vaadin.data.Validator;
//
//import gov.doi.tw.civilpenalties.backend.model.logging.CpLogger;
//
//public class AmountValidator  implements Validator{
//
//	@Override
//	public void validate(Object value) throws InvalidValueException {
//		String valueStr;
//		try {
//			if(value instanceof String) {
//				valueStr=(String) value;
//				valueStr = valueStr.trim();
//				if (valueStr.contains("-")) {// negative check
//					throw new InvalidValueException("Value cannot be negative - " + value);
//				} else if (valueStr.contains(".")) {
//					throw new InvalidValueException("Value cannot be decimal number - " + value);
//					// throw new ConversionException("Value cannot be decimal number. " + value);
//				} else if (valueStr.contains(",")) {
//					throw new InvalidValueException("No symbol is allowed in the value - " + value);
//					// throw new ConversionException("No symbol is allowed in the value. " + value);
//				} else if (!StringUtils.isNumeric(valueStr)) {
//					throw new InvalidValueException("Non numeric characters are not allowed - " + value);
//					// throw new ConversionException("No symbol is allowed in the value. " + value);
//				}  
//				else {
//					try {
//						Long convertedValue = Long.parseLong(valueStr);
//					}catch (Exception e) {
//						throw new InvalidValueException("Value is not an acceptable digit -" + value);
//					}
//					
//				}
//			}
//			
//
//		} catch (NumberFormatException | ClassCastException e) {
//			CpLogger.error(e);
//			// CpLogger.error(e);
//			// throw new ConversionException("Value is not a digit. " + value);
//			throw new InvalidValueException("Value is not an acceptable digit." + value);
//
//		}
//	}
//
//}
